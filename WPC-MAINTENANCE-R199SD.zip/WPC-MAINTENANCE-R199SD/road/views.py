from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.models import auth,User
from django.contrib.auth import logout
from django.contrib import messages
from .models import data,contact_us
from datetime import date
# Create your views here.
today = date.today()
def user_home(request):
    return render(request,'user_home.html')
def m_home(request):    
    return render(request,'m_home.html')
def maintenance_page1(request):
    name = request.user.username
    data1 = data.objects.filter(main_by=name)
    data2 = data.objects.filter(main_by=name).exclude(status='completed')
    status = ['inprogress','completed','halted']
    return render(request,'m1.html',{'data1': data1,'name': name,'data2': data2,'status': status})
def maintenance_page2(request):
    if request.method == "POST":
        name = request.user.username
        id = request.POST['select']
        dat = data.objects.get(main_id=id)
        return render(request,'m2.html',{'dat': dat,'name':name})
def signin(request):
    if request.method == "POST":
        us = request.POST['username']
        pas = request.POST['pass']
        user = auth.authenticate(username=us,password=pas)
        if user is not None:
            auth.login(request,user)
            return redirect('maintenance_page1')
        else:
            messages.error(request,'Invalid credentials')
            return redirect('signin')
    else:
        return render(request,'signin.html')


def signup(request):     
    if request.method == "POST":
        em = request.POST['email']
        us = request.POST['username']
        pas = request.POST['pass']
        pas1 = request.POST['repass']
        if pas == pas1:
            if User.objects.filter(email=em).exists():
                messages.info(request,'email alreday exist')
                return redirect('signup')
            elif User.objects.filter(username=us).exists():
                messages.info(request,'username alreday taken')
                return redirect('signup')
            else:
                user = User.objects.create_user(email=em,username=us,password=pas)
                user.save()
                return redirect('signin')
        else:
            messages.error(request,"password didn't match")
            return redirect('signup')
    else:
        return render(request,'signup.html')

def form1_submit(request):
    if request.method == 'POST':
        road = request.POST['road']
        budget = request.POST['budget']
        workers = request.POST['workers']
        date = request.POST['date']
        proof = request.POST['proof']
        dis = request.POST['distance']
        c_user = request.user.username
        raw_id = data.objects.last()
        id = str((int(raw_id.main_id)+1))
        add_record = data( main_id=id ,main_by=c_user ,road=road,status="started",budget=budget,
        no_of_wrkr=workers,distance=dis,proof=proof,s_date=today,e_e_date=date)
        add_record.save()
        return redirect('maintenance_page1')

def form2_submit(request):
    if request.method== 'POST':
        ids = request.POST['select']
        upd = request.POST['update']
        modify = data.objects.get(main_id=ids)
        if upd == 'completed':
            modify.e_date=today
        modify.status=upd
        modify.save()
        messages.info(request,'status updated successfully')
        return redirect('maintenance_page1')

def user_page1(request):
    da = data.objects.all()
    return render(request,'data.html',{'da':da})

def contactus_form(request):
    if request.method == 'POST':
        nam = request.POST['name']
        em = request.POST['email']
        msg = request.POST['message']
        phn = request.POST['phone']
        data = contact_us(name=nam,email=em,message=msg,phone=phn)
        data.save()
        return render(request,'user_home.html')
    

def Logout(request):
    auth.logout(request)
    return redirect('signin')